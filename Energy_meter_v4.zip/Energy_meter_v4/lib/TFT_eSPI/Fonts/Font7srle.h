#include <Fonts/Font7srle.c>

#define nr_chrs_f7s 96
#define chr_hgt_f7s 48
#define baseline_f7s 47
#define data_size_f7s 8
#define firstchr_f7s 32

extern const unsigned char widtbl_f7s[96];
extern const unsigned char* const chrtbl_f7s[96];
