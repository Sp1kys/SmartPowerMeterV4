#include <TFT_eSPI.h>                 // Include the graphics library (this includes the sprite functions)

extern const uint8_t stars[12800] PROGMEM ;